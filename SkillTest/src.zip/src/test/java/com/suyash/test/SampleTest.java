package com.suyash.test;

import org.testng.annotations.Test;

import pageEvents.LoginPageEvents;

public class SampleTest extends baseTest {
	
	@Test
	public void sampleMethodLogin() {
		
		LoginPageEvents loginPageEvents = new LoginPageEvents();
		loginPageEvents.clickOnLogin();
		
	}

}
