package utils;

public interface Constants {
	
	String url = "https://www.amazon.com";

}
