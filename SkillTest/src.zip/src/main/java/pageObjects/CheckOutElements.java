package pageObjects;

public interface CheckOutElements {

}
