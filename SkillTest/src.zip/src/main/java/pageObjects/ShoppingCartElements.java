package pageObjects;

public interface ShoppingCartElements {

}
