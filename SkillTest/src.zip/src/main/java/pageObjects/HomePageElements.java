package pageObjects;

public interface HomePageElements {

}
