package pageObjects;

public interface LoginPageElements {

	String loginButton = "//input[@id='login-button']";
	String userName = "//input[@id='user-name']";
	String password = "//input[@id='password']";

	
}
