package pageEvents;

public class CheckoutEvents {

}
