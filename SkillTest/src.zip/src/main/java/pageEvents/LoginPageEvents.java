package pageEvents;

import pageObjects.LoginPageElements;
import utils.ElementFetch;

public class LoginPageEvents {
	
	public void clickOnLogin() {
		
		ElementFetch elementFetch = new ElementFetch();
		elementFetch.getWebElement("XPATH",LoginPageElements.loginButton).click();
		
	}
	

}
