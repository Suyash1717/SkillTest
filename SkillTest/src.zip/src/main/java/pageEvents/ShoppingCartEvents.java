package pageEvents;

public class ShoppingCartEvents {

}
